#pragma once
#include <string>

class Animal
{
public:
	virtual int GetNumberOfLegs() = 0;
	virtual std::string GetClass();
};