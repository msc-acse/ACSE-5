#include <iostream>
#include <string>
#include <sstream>

std::string sleeping(int times)
{
	std::stringstream s;
	for (int i = 0; i < times; i++)
		s << "relax!";
	return s.str();
}

std::string talking(int times)
{
	std::stringstream s;
	for (int i = 0; i < times; i++)
		s << "think!";
	return s.str();
}

std::string running(int times)
{
	std::stringstream s;
	for (int i = 0; i < times; i++)
		s << "be careful!";
	return s.str();
}

void print_thoughts(std::string (*f)(int), int times)
{
	std::cerr << (*f)(times);
}

int main()
{
	print_thoughts(sleeping, 5);
	std::cerr << "\n\n\n";
	print_thoughts(running, 5);
	std::cerr << "\n\n\n";
	system("pause");
}