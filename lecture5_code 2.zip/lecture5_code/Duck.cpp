#include "Duck.h"

std::string Duck::GetClass()
{
	return "Duck";
}

int Duck::GetNumberOfLegs()
{
	return 2;
}