#include "Animal.h"

std::string Animal::GetClass() 
{ 
	return "Animal"; 
}