#include "Horse.h"

std::string Horse::GetClass()
{
	return "Horse";
}

int Horse::GetNumberOfLegs()
{
	return 4;
}