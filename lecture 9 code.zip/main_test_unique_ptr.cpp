#include <iostream>
#include <math.h>
#include <ctime>
#include <memory>

using namespace std;

// Super simple function that leaks memory
void doSomething(int input, double other_input)
{
   cout << "Hello!";
   // What happens if I don't call delete on this before exiting??
   // This is stored on the heap
   int *int_array = new int[input];
   
   // Return to the function - Memory leak on int_arrays
   return;
}

// Super simple function that doesn't leaks memory
void doSomethingUniquePtr(int input, double other_input)
{
   cout << "Hello!";
   // This syntax just looks ilke a constructor!
   // You feed it a pointer
   // Note there is special syntax here to tell the unique_ptr that 
   // it is pointing at an int array - this is so the unique_ptr knows
   // which version of delete to call
   unique_ptr<int[]> int_array(new int[input]);
   // For example this leaks memory! As it calls delete on *int_array, which 
   // is a pointer to the first element in the array, rather than call delete[]
   unique_ptr<int> int_array_two(new int[input]);
   
   // Return to the function - don't have to worry about deleting int_array!
   return;
}

// Super simple function that does leaks memory
void doSomethingUniquePtrLeak(int input, double other_input)
{
   cout << "Hello!";
   // This syntax just looks ilke a constructor!
   // You feed it a pointer
   unique_ptr<int[]> int_array(new int[input]);

   // This gives us a raw pointer to the thing in int_array and 
   // releases ownership - This means we are responsible for the memory now!
   int *raw_ptr = int_array.release();
   
   // Return to the function - Memory leak without deleting raw_ptr!
   return;
}

// Super simple function that does leaks memory
void doSomethingUniquePtrReset(int input, double other_input)
{
   cout << "Hello!";
   int *raw_ptr = new int[input];

   // This syntax just looks ilke a constructor!
   // You feed it a pointer
   unique_ptr<int[]> int_array(raw_ptr);

   // If we returned now we don't have to worry about a memory leak
   int *raw_ptr_other = new int[input * 2];
   // This deletes the original object we have ownership over and replaces it with 
   // our new pointer
   // But after this raw_ptr is invalid so we can't use it
   int_array.reset(raw_ptr_other);

   // Return to the function - No memory leak
   return;
}

int main()
{

   // We know these are stored on the stack
   int value = 5;
   double other_value = 10.96;

   // This will leak memory
   doSomething(value, other_value);
   // This will not leak memory
   doSomethingUniquePtr(value, other_value);   
   // This will leak memory
   doSomethingUniquePtrLeak(value, other_value);      
   // This will not leak memory
   doSomethingUniquePtrReset(value, other_value);      

   system("pause");

}