#pragma once
#include <string>

struct GPS_Coordinates
{
	double longitude_;
	double latitude_;
};

//BASE CLASS - DESIGN
class GPS_Device
{
public: //I can inherit
	GPS_Device() {}
	void Name();
	double Weight();
	virtual GPS_Coordinates Ping()
	{
		GPS_Coordinates coords;
		coords.longitude_ = -1;
		coords.latitude_ = -1;
		return coords;
	}//sending message
protected: //I can inherit
	int serial_number_;
private:
	std::string name_;
	double weight_;
	GPS_Coordinates coordinates_;
};

class GPS_Car : public GPS_Device
{

};

class GPS_Pet_Device : public GPS_Device //interface
{
};

//DERIVED CLASS - SPECIALISE
class GPS_Collar : public GPS_Pet_Device
{
public:
	GPS_Coordinates Ping() 
	{ 
		GPS_Coordinates coords;
		coords.longitude_ = 0;
		coords.latitude_ = 0;
		return coords;
	}
};

class GPS_EdibleChip : public GPS_Pet_Device
{
public: 
	GPS_Coordinates Ping()
	{
		GPS_Coordinates coords;
		coords.longitude_ = rand();
		coords.latitude_ = rand();
		return coords;
	}
};

class GPS_Basic : public GPS_Pet_Device
{
};