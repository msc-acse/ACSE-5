#include "Pet.h" //no need to include .cpp files ever! only .h files
#include <iostream> //these are also headers, but system files (we use <> for those)

//Definitions
template<class T>
Pet<T>::Pet()
{
	//this is to randomly define myGPS_ if we were using polymorphism
	//int myLuck = rand() % 100;
	//if (myLuck % 2 == 0)
	//{
		//myGPS_ = new GPS_EdibleChip; //created during runtime
	//}
	//else
	//	myGPS_ = new GPS_Collar;
}

//this class implements calling the pet
template<class T>
void Pet<T>::CallMyPet(std::vector<std::string> calling_the_pet)
{
	for (auto s : calling_the_pet) //range for loop 
	{
		std::cerr << std::endl << s << "!";
		GPS_Coordinates coord = myGPS_.Ping();
		std::cerr << std::endl << " Coord: " << coord.latitude_ << "-" << coord.longitude_;
	}
}

//this is the template instantiation, you need it for every type of template class you will be using
template class Pet < GPS_EdibleChip >;
//you could also define:
//template class Pet < GPS_Collar >;
