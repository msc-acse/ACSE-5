#pragma once

#include <vector>
#include <string>
#include "GPS_Device.h"

enum TypeOfPet { Bird, Dog, Cat, Fish };

//Declarations
template<class T>//, int number_of_owners>
class Pet
{
public:
	Pet();
	void CallMyPet(std::vector<std::string> calling_the_pet);

private:
	TypeOfPet type_;
	//GPS_Pet_Device* myGPS_; //if we use polymorphism
	
	//GPS_Basic basicGPS; //static copy created once at the start
	T myGPS_;
	//std::string owners[number_of_owners];
};