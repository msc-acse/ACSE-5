#include <iostream>
#include "Pet.h"

//World location information - GPS
//Information Pet
//Pet Owner
//GPS Device
//User device

//typedef std::vector < double >  GPS_Coordinates;

int main()
{
	std::cerr << "\nHello again...";
	
	std::vector<std::string> calling_words;
	calling_words.push_back("Hey");
	calling_words.push_back("come back");
	calling_words.push_back("Joeeeee");
	
	Pet<GPS_EdibleChip> joe;
	joe.CallMyPet(calling_words);

	system("pause");
}

/*GPS_Device* device; //base
	int random_int(rand() % 100);
	if (random_int % 2 == 0)
	{
		device = new GPS_Collar;
	}
	else if (random_int % 3 == 0)
	{
		device = new GPS_EdibleChip;
	}
	else if (random_int % 5 == 0)
	{
		device = new GPS_Car;
		}*/